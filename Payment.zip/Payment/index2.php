<?php

echo "Thanks your payment has been successfully gone ";

?>